import { render } from "@testing-library/react";
import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Link, Route, Switch } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

import HeaderMail from './components/EmailBox/HeaderMail'


function App() {
  return (

    <div>
     <HeaderMail/>
    </div>
  );
}
export default App;
