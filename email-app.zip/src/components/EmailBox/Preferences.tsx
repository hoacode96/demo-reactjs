import * as React from 'react';



const Preferences = () => {
  return (
    <h1>Page Preferences is under Construction</h1>
  )
};

export default Preferences;
