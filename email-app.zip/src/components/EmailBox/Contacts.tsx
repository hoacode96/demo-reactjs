import * as React from 'react';



const Contacts = () => {
  return (
      <h1>Page Contact is under Construction</h1>
  )
};

export default Contacts;
