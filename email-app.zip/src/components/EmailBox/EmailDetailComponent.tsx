import * as React from "react";
import { Button } from "react-bootstrap";
import Moment from "react-moment";
import { useParams } from "react-router-dom";
const EmailDetailComponent = ({ passedData }: any) => {
  let { mailId }: any = useParams();
  return (
    <div
      style={{
        marginLeft: "50px",
        position: "fixed",
        top: "500px",
        width: "80%",
        overflow: "auto",
      }}
    >
      <div>
        {passedData
          .filter((ele: any) => {
            return ele._id === mailId;
          })
          .map((ele2: any) => {
            return (
              <div>
                <div>
                  <h4>{ele2.subject}</h4>
                  <p>{ele2.from + " ==> " + ele2.to}</p>
                  <p>
                    <Moment format="DD-MM-YYYY">{ele2.date}</Moment>
                  </p>
                  <Button variant="btn btn-outline-primary">Reply</Button>{" "}
                  <Button variant="btn btn-outline-primary">Forward</Button>{" "}
                  <Button variant="btn btn-outline-primary">Delete</Button>
                </div>
                <div>
                  <article>{`${ele2.body}`}</article>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
};

export default EmailDetailComponent;
